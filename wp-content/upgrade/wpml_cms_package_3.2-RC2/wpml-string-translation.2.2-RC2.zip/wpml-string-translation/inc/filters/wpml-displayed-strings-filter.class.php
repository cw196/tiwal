<?php

class WPML_Displayed_String_Filter {

	protected $language;
	protected $name_cache = array();

	public function __construct( $language ) {
		$this->language = $language;
		$this->warm_cache();
	}

	protected function warm_cache() {
		global $wpdb;

		$query = $wpdb->prepare( "
					SELECT st.value AS tra, s.name AS nam, s.value AS org, s.context AS ctx
					FROM {$wpdb->prefix}icl_strings s
					JOIN {$wpdb->prefix}icl_string_translations st
						ON s.id = st.string_id
					WHERE st.status = %d AND st.language = %s",
		                         ICL_TM_COMPLETE,$this->language );
		$res   = $wpdb->get_results( $query, ARRAY_A );

		$name_cache = array();
		foreach ( $res as $str ) {
			$name_cache[ $str[ 'nam' ] . $str[ 'ctx' ] ] = &$str[ 'tra' ];
		}

		$this->name_cache = $name_cache;
	}

	public function translate_by_name_and_context( $untranslated_text, $name, $context = "", &$has_translation = null ) {


		$res             = $this->string_from_registered( $name, $context );
		$res             = $res === false && $context === 'default' ? $this->string_from_registered( $name, 'WordPress' ) : $res;
		$res             = $res === false && $context === 'WordPress' ? $this->string_from_registered( $name, 'default' ) : $res;
		$has_translation = $res !== false ? true : null;
		$res             = ( $res === false && $untranslated_text !== false ) ? $untranslated_text : $res;

		if ( $res === false ) {
			$res = $this->string_by_name_and_ctx( $name, $context );
		}

		return $res;
	}

	protected function string_from_registered( $name, $context = "" ) {
		list( $name, $context ) = $this->truncate_name_and_context( $name, $context );
		
		$key = $name . $context;
		$res = isset( $this->name_cache[ $key ] ) ? $this->name_cache[ $key ] : false;

		return $res;
	}
	
	protected function truncate_name_and_context( $name, $context) {
		if (strlen( $name ) > WPML_STRING_TABLE_NAME_CONTEXT_LENGTH ) {
			// truncate to match length in db
			$name = substr( $name, 0, intval( WPML_STRING_TABLE_NAME_CONTEXT_LENGTH ) );
		}
		if (strlen( $context ) > WPML_STRING_TABLE_NAME_CONTEXT_LENGTH ) {
			// truncate to match length in db
			$context = substr( $context, 0, intval( WPML_STRING_TABLE_NAME_CONTEXT_LENGTH ) );
		}
		
		return array( $name, $context );
	}

	public function export_cache() {
		return array(
			'name_cache' => $this->name_cache,
		);
	}

	protected function string_by_name_and_ctx( $name, $context ) {
		/** @var wpdb $wpdb */
		global $wpdb;

		$query = $wpdb->prepare( "SELECT value FROM {$wpdb->prefix}icl_strings WHERE name = %s AND context = %s LIMIT 1",
		                         $name,
		                         $context );

		$value = $wpdb->get_var( $query );

		if ( $value !== null ) {
			$this->name_cache[ $name . $context ] = $value;
		}

		return $value;
	}
}