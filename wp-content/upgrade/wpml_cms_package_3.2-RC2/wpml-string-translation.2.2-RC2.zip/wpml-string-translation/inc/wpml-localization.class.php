<?php

class WPML_Localization {

	public function get_theme_localization_stats() {
		global $wpdb;

		$theme_localization_domains = icl_get_sub_setting( 'st', 'theme_localization_domains' );
		$results                    = array();
		if ( $theme_localization_domains ) {
			$domains = array();

			foreach ( (array) $theme_localization_domains as $domain ) {
				$domains[ ] = $domain ? 'theme ' . $domain : 'theme';
			}
			if ( ! empty( $domains ) ) {
				$results = $wpdb->get_results( "
		            SELECT context, status, COUNT(id) AS c
		            FROM {$wpdb->prefix}icl_strings
		            WHERE context IN ('" . join( "','", $domains ) . "')
		            GROUP BY context, status
		        " );
			}
		}

		return $this->results_to_array( $results );
	}

	public function get_plugin_localization_stats() {
		global $wpdb;

		$results = $wpdb->get_results( "
	        SELECT context, status, COUNT(id) AS c
	        FROM {$wpdb->prefix}icl_strings
	        WHERE context LIKE ('plugin %')
	        GROUP BY context, status
	    " );

		return $this->results_to_array( $results );
	}

	private function results_to_array( $results ) {
		$stats = array();

		foreach ( $results as $r ) {
			if ( ! isset( $stats[ $r->context ][ 'complete' ] ) ) {
				$stats[ $r->context ][ 'complete' ] = 0;
			}
			if ( ! isset( $stats[ $r->context ][ 'incomplete' ] ) ) {
				$stats[ $r->context ][ 'incomplete' ] = 0;
			}
			if ( $r->status == ICL_TM_COMPLETE ) {
				$stats[ $r->context ][ 'complete' ] = $r->c;
			} else {
				$stats[ $r->context ][ 'incomplete' ] += $r->c;
			}
		}

		return $stats;
	}
}