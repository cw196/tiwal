<?php

class WPML_String_Translation
{
	var $load_priority = 400;
	private $messages = array();
	private $string_filters = array();
	private $strings_autoregister;

	function __construct()
	{
		if ( defined( 'WPML_TM_VERSION' ) ) {
			add_action( 'wpml_tm_loaded', array( $this, 'load' ) );
		} else {
			add_action( 'wpml_loaded', array( $this, 'load' ), $this->load_priority );
		}
		add_action( 'init', array($this, 'verify_wpml') );
	}
	
	function __destruct()
	{

	}

	function verify_wpml() {
		if ( ! defined('ICL_SITEPRESS_VERSION') ) {
			add_action( 'admin_notices', array('WPML_String_Translation', 'notice_no_wpml') );
		}
	}
	
	static function notice_no_wpml() {
		?>
	    <div class="error">
	        <p><?php _e( 'Please activate WPML Multilingual CMS to have WPML String Translation working.', 'wpml-translation-management' ); ?></p>
	    </div>
	    <?php
	}
	
	function _wpml_not_installed_warning(){
		?>
			<div class="message error"><p><?php printf(__('WPML String Translation is enabled but not effective. Please finish the installation of WPML first.', 'wpml-translation-management') ); ?></p></div>
		<?php
	}
	
	
	public function load() {
		
		global $sitepress;
		
		if ( ! $sitepress ) {
			return;
		}
		elseif ( ! $sitepress->get_setting( 'setup_complete' ) ) {
			add_action( 'admin_notices', array( $this, '_wpml_not_installed_warning' ) );
			return;
		} 
		
		require WPML_ST_PATH . '/inc/widget-text.php';
		require WPML_ST_PATH . '/inc/filters/wpml-displayed-strings-filter.class.php';
		require WPML_ST_PATH . '/inc/filters/wpml-admin-string-filter.class.php';
		require WPML_ST_PATH . '/inc/wpml-localization.class.php';
		require WPML_ST_PATH . '/inc/gettext/wpml-string-translation-mo-import.class.php';

		require WPML_ST_PATH . '/inc/functions.php';
		require WPML_ST_PATH . '/inc/wpml-string-shortcode.php';
		include WPML_ST_PATH . '/inc/slug-translation.php';
		require_once WPML_ST_PATH . '/inc/wpml-admin-texts.class.php';

		WPML_Admin_Texts::get_instance();

		add_action( 'init', array( $this, 'init' ) );
		add_action( 'init', array( 'WPML_Slug_Translation', 'init' ) );

		add_filter( 'pre_update_option_blogname', array( $this, 'pre_update_option_blogname' ), 5, 2 );
		add_filter( 'pre_update_option_blogdescription', array( $this, 'pre_update_option_blogdescription' ), 5, 2 );

		//Handle Admin Notices
		if ( isset( $GLOBALS[ 'pagenow' ] ) && ! ( in_array( $GLOBALS[ 'pagenow' ], array( 'wp-login.php', 'wp-register.php' ) ) ) ) {
			self::_st_warnings();
		}

		add_action( 'icl_ajx_custom_call', array( $this, 'ajax_calls' ), 10, 2 );
		add_action( 'init', array( $this, 'set_auto_register_status' ) );

		add_filter( 'WPML_ST_strings_language', array( $this, 'get_strings_language' ) );
		add_filter( 'WPML_ST_strings_context_language', array( $this, 'get_default_context_language' ), 10, 2 );

		add_action('wpml_st_delete_all_string_data', array($this, 'delete_all_string_data'), 10, 1);

		do_action( 'wpml_st_loaded' );
	}

	function init() {

		global $sitepress;

		if ( is_admin() ) {
			wp_enqueue_style( 'thickbox' );
			wp_enqueue_script( 'jquery' );
			wp_enqueue_script( 'thickbox' );
		}


		if ( is_admin() ) {
			require_once WPML_ST_PATH . '/inc/auto-download-locales.php';
			global $WPML_ST_MO_Downloader;
			$WPML_ST_MO_Downloader = new WPML_ST_MO_Downloader();
		}

		$this->plugin_localization();

		add_action( 'admin_menu', array( $this, 'menu' ) );

		add_filter( 'plugin_action_links', array( $this, 'plugin_action_links' ), 10, 2 );

		if ( is_admin() && isset( $_GET[ 'page' ] ) && ( $_GET[ 'page' ] == WPML_ST_FOLDER . '/menu/string-translation.php' || $_GET[ 'page' ] == ICL_PLUGIN_FOLDER . '/menu/theme-localization.php' ) ) {
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_style( 'wp-color-picker'  );
			wp_enqueue_script( 'wpml-st-scripts', WPML_ST_URL . '/res/js/scripts.js', array(), WPML_ST_VERSION );
			wp_enqueue_style( 'wpml-st-styles', WPML_ST_URL . '/res/css/style.css', array(), WPML_ST_VERSION );
		}

		if ( $sitepress && $sitepress->get_setting( 'theme_localization_type' ) && $sitepress->get_setting( 'theme_localization_type' ) == 1 ) {
			add_action( 'icl_custom_localization_type', array( $this, 'localization_type_ui' ) );
		}

		add_action( 'wp_ajax_icl_tl_rescan', array( $this, 'tl_rescan' ) );
		add_action( 'wp_ajax_icl_tl_rescan_p', array( $this, 'tl_rescan_p' ) );
		add_action( 'wp_ajax_icl_st_pop_download', array( $this, 'plugin_po_file_download' ) );
		add_action( 'wp_ajax_icl_st_cancel_local_translation', array( $this, 'icl_st_cancel_local_translation' ) );
		add_action( 'wp_ajax_icl_st_string_status', array( $this, 'icl_st_string_status' ) );

		// add message to WPML dashboard widget
		add_action( 'icl_dashboard_widget_content', array( $this, 'icl_dashboard_widget_content' ) );

		return true;
	}

	function plugin_localization()
	{
		load_plugin_textdomain( 'wpml-string-translation', false, WPML_ST_FOLDER . '/locale' );
	}

	static function _st_warnings()
	{
		if(!class_exists('ICL_AdminNotifier')) return;

		$string_settings = apply_filters('WPML_get_setting', false, 'st' );

		if(isset($string_settings[ 'strings_language' ] )) {
			global $sitepress;
			if ( $sitepress->get_default_language() != $string_settings[ 'strings_language' ] ) {
				self::_st_default_language_warning();
			} elseif ( $string_settings[ 'strings_language' ] != 'en' ) {
				self::_st_default_and_st_language_warning();
			} else {
				ICL_AdminNotifier::removeMessage( '_st_default_and_st_language_warning' );
				ICL_AdminNotifier::removeMessage( '_st_default_language_warning' );
			}
		}
	}

	static function _st_default_language_warning()
	{

		ICL_AdminNotifier::removeMessage( '_st_default_and_st_language_warning' );
		static $called = false;
		if ( !$called ) {
			global $sitepress;
			$languages             = $sitepress->get_active_languages();
			$translation_languages = array();
			foreach ( $languages as $language ) {
				if ( $language[ 'code' ] != 'en' ) {
					$translation_languages[ ] = $language[ 'display_name' ];
				}
			}
			$last_translation_language = $translation_languages[ count( $translation_languages ) - 1 ];
			unset( $translation_languages[ count( $translation_languages ) - 1 ] );
			$translation_languages_list = is_Array( $translation_languages ) ? implode( ', ', $translation_languages ) : $translation_languages;

			$message = 'Because your default language is not English, you need to enter all strings in English and translate them to %s and %s.';
			$message .= ' ';
			$message .= '<strong><a href="%s" target="_blank">Read more</a></strong>';

			$message = __( $message, 'Read more string-translation-default-language-not-english', 'wpml-string-translation' );
			$message = sprintf( $message, $translation_languages_list, $last_translation_language, 'https://wpml.org/faq/string-translation-default-language-not-english/' );

			$fallback_message = __( '<a href="%s" target="_blank">How to translate strings when default language is not English</a>' );
			$fallback_message = sprintf( $fallback_message, 'https://wpml.org/faq/string-translation-default-language-not-english/' );

			ICL_AdminNotifier::addMessage( '_st_default_language_warning', $message, 'icl-admin-message-information', true, $fallback_message, false, 'string-translation' );
			$called = true;
		}
	}

	static function _st_default_and_st_language_warning()
	{
		global $sitepress;

		$string_settings = apply_filters('WPML_get_setting', false, 'st' );

		if(isset($string_settings[ 'strings_language' ] )) {
			ICL_AdminNotifier::removeMessage( '_st_default_language_warning' );
			static $called = false;
			if (defined('WPML_ST_FOLDER') && !$called ) {
				$st_language_code = $string_settings[ 'strings_language' ];
				$st_language = $sitepress->get_display_language_name($st_language_code, $sitepress->get_admin_language());

				$page = WPML_ST_FOLDER . '/menu/string-translation.php';
				$st_page_url = admin_url('admin.php?page=' . $page);

				$message = __(
					'The strings language in your site is set to %s instead of English.
					This means that all English texts that are hard-coded in PHP will appear when displaying content in %s.
					<strong><a href="%s" target="_blank">Read more</a> |  <a href="%s#icl_st_sw_form">Change strings language</a></strong>',
				'wpml-string-translation' );

				$message = sprintf( $message, $st_language, $st_language, 'https://wpml.org/faq/string-translation-default-language-not-english/', $st_page_url );

				$fallback_message = __( '<a href="%s" target="_blank">How to translate strings when default language is not English</a>', 'wpml-string-translation' );
				$fallback_message = sprintf( $fallback_message, 'https://wpml.org/faq/string-translation-default-language-not-english/' );

				ICL_AdminNotifier::addMessage( '_st_default_and_st_language_warning', $message, 'icl-admin-message-warning', true, $fallback_message, false, 'string-translation' );
				$called = true;
			}
		}
	}

	function add_message( $text, $type = 'updated' )
	{
		$this->messages[ ] = array( 'type' => $type, 'text' => $text );
	}

	function show_messages()
	{
		if ( !empty( $this->messages ) ) {
			foreach ( $this->messages as $m ) {
				printf( '<div class="%s fade"><p>%s</p></div>', $m[ 'type' ], $m[ 'text' ] );
			}
		}
	}

	function ajax_calls( $call, $data )
	{
		switch ( $call ) {

			case 'icl_st_save_translation':
				$icl_st_complete = isset( $data[ 'icl_st_translation_complete' ] ) && $data[ 'icl_st_translation_complete' ] ? ICL_TM_COMPLETE : ICL_TM_NOT_TRANSLATED;
				if ( get_magic_quotes_gpc() ) {
					$data = stripslashes_deep( $data );
				}
				if ( icl_st_is_translator() ) {
					$translator_id = get_current_user_id() > 0 ? get_current_user_id() : null;
				} else {
					$translator_id = null;
				}
				echo icl_add_string_translation( $data[ 'icl_st_string_id' ], $data[ 'icl_st_language' ], stripslashes( $data[ 'icl_st_translation' ] ), $icl_st_complete, $translator_id );
				echo '|';
				global $icl_st_string_translation_statuses;

				$ts = icl_update_string_status( $data[ 'icl_st_string_id' ] );

				if ( icl_st_is_translator() ) {
					$ts = icl_get_relative_translation_status( $data[ 'icl_st_string_id' ], $translator_id );
				}

				echo $icl_st_string_translation_statuses[ $ts ];
				break;
			case 'icl_st_delete_strings':
				$arr = explode( ',', $data[ 'value' ] );
				__icl_unregister_string_multi( $arr );
				break;
			case 'icl_st_option_writes_form':
				if ( !empty( $data[ 'icl_admin_options' ] ) ) {
					$wpml_admin_text = WPML_Admin_Texts::get_instance();
					$wpml_admin_text->icl_register_admin_options( $data[ 'icl_admin_options' ] );
					echo '1|';
				} else {
					echo '0' . __( 'No strings selected', 'wpml-string-translation' );
				}
				break;

			// OBSOLETE?
			case 'icl_st_ow_export':
				// filter empty options out
				do {
					list( $data[ 'icl_admin_options' ], $empty_found ) = _icl_st_filter_empty_options_out( $data[ 'icl_admin_options' ] );
				} while ( $empty_found );

				if ( !empty( $data[ 'icl_admin_options' ] ) ) {

					foreach ( $data[ 'icl_admin_options' ] as $k => $opt ) {
						if ( !$opt ) {
							unset( $data[ 'icl_admin_options' ][ $k ] );
						}
					}

					$wpml_admin_text = WPML_Admin_Texts::get_instance();
					$message = __( 'Save the following to a wpml-config.xml in the root of your theme or plugin.', 'wpml-string-translation' )
						. "<textarea wrap=\"soft\" spellcheck=\"false\">" . htmlentities($wpml_admin_text->get_wpml_config_file($data[ 'icl_admin_options' ] )) .
							"</textarea>";
				} else {
					$message = __( 'Error: no strings selected', 'wpml-string-translation' );
				}
				echo json_encode( array( 'error' => 0, 'message' => $message ) );
				break;


		}
	}

	function menu() {
		if ( ! defined( 'ICL_PLUGIN_PATH' ) ) {
			return;
		}

		$setup_complete = apply_filters( 'WPML_get_setting', false, 'setup_complete' );
		if ( ! $setup_complete ) {
			return;
		}

		global $wpdb;
		$existing_content_language_verified = apply_filters( 'WPML_get_setting',
		                                                     false,
		                                                     'existing_content_language_verified' );

		if ( ! $existing_content_language_verified ) {
			return;
		}

		if ( current_user_can( 'wpml_manage_string_translation' ) ) {
			$top_page = apply_filters( 'icl_menu_main_page', basename( ICL_PLUGIN_PATH ) . '/menu/languages.php' );

			add_submenu_page( $top_page,
			                  __( 'String Translation', 'wpml-string-translation' ),
			                  __( 'String Translation', 'wpml-string-translation' ),
			                  'wpml_manage_string_translation',
			                  WPML_ST_FOLDER . '/menu/string-translation.php' );
		} else {
			$string_settings = apply_filters('WPML_get_setting', false, 'st' );
			
			$user_lang_pairs = get_user_meta( get_current_user_id(), $wpdb->prefix . 'language_pairs', true );
			if ( isset( $string_settings[ 'strings_language' ] ) && !empty( $user_lang_pairs[ $string_settings[ 'strings_language' ] ] ) ) {
				add_menu_page( __( 'String Translation', 'wpml-string-translation' ),
				               __( 'String Translation', 'wpml-string-translation' ),
				               'translate',
				               WPML_ST_FOLDER . '/menu/string-translation.php',
				               null,
				               ICL_PLUGIN_URL . '/res/img/icon16.png' );
			}

		}
	}

	function plugin_action_links( $links, $file )
	{
		$this_plugin = basename( WPML_ST_PATH ) . '/plugin.php';
		if ( $file == $this_plugin ) {
			$links[ ] = '<a href="admin.php?page=' . WPML_ST_FOLDER . '/menu/string-translation.php">' .
				__( 'Configure', 'wpml-string-translation' ) . '</a>';
		}

		return $links;
	}

	function localization_type_ui()
	{
		include WPML_ST_PATH . '/menu/theme-localization-ui.php';

	}

	function tl_rescan()
	{
		global $wpdb, $sitepress_settings;

		$scan_stats = icl_st_scan_theme_files();

		if ( isset( $_POST[ 'icl_load_mo' ] ) && $_POST[ 'icl_load_mo' ] ) {
			$mo_files = icl_st_get_mo_files( TEMPLATEPATH );
			foreach ( (array)$mo_files as $m ) {
				$i = preg_match( '#[-]?([a-z_]+)\.mo$#i', $m, $matches );
				if ( $i && $lang = $wpdb->get_var( "SELECT code FROM {$wpdb->prefix}icl_locale_map WHERE locale='" . $matches[ 1 ] . "'" ) ) {
					$tr_pairs = icl_st_load_translations_from_mo( $m );
					foreach ( $tr_pairs as $original => $translation ) {
						foreach ( $sitepress_settings[ 'st' ][ 'theme_localization_domains' ] as $tld ) {
							$string_id = icl_get_string_id( $original, 'theme ' . $tld );
							if ( $string_id ) {
								if ( !$wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}icl_string_translations WHERE string_id=%d AND language=%s", $string_id, $lang  ) ) ) {
									icl_add_string_translation( $string_id, $lang, $translation, ICL_TM_COMPLETE );
								}
								break;
							}
						}
					}
				}
			}
		}

		echo '1|' . $scan_stats;
		exit;

	}

	function tl_rescan_p()
	{
		global $wpdb;

		set_time_limit( 0 );
		if ( preg_replace( '#M$#', '', ini_get( 'memory_limit' ) ) < 128 )
			ini_set( 'memory_limit', '128M' );
		$plugins = array();
		if ( !empty( $_POST[ 'plugin' ] ) )
			foreach ( $_POST[ 'plugin' ] as $plugin ) {
				$plugins[ ] = array( 'file' => $plugin, 'mu' => 0 ); // regular plugins
			}
		if ( !empty( $_POST[ 'mu-plugin' ] ) )
			foreach ( $_POST[ 'mu-plugin' ] as $plugin ) {
				$plugins[ ] = array( 'file' => $plugin, 'mu' => 1 ); //mu plugins
			}
		$scan_stats = '';
		foreach ( $plugins as $p ) {
			$plugin = $p[ 'file' ];

			if ( false !== strpos( $plugin, '/' ) && !$p[ 'mu' ] ) {
				$plugin = dirname( $plugin );
			}
			if ( $p[ 'mu' ] ) {
				$plugin_path = WPMU_PLUGIN_DIR . '/' . $plugin;
			} else {
				$plugin_path = WP_PLUGIN_DIR . '/' . $plugin;
			}

			$scan_stats .= icl_st_scan_plugin_files( $plugin_path );

			if ( $_POST[ 'icl_load_mo' ] && !$p[ 'mu' ] ) {
				$mo_files = icl_st_get_mo_files( $plugin_path );
				foreach ( $mo_files as $m ) {
					$i = preg_match( '#[-]([a-z_]+)\.mo$#i', $m, $matches );
					if ( $i && $lang = $wpdb->get_var( "SELECT code FROM {$wpdb->prefix}icl_locale_map WHERE locale='" . $matches[ 1 ] . "'" ) ) {
						$tr_pairs = icl_st_load_translations_from_mo( $m );
						foreach ( $tr_pairs as $original => $translation ) {
							$string_id = icl_get_string_id( $original, 'plugin ' . basename( $plugin_path ) );
							if ( !$wpdb->get_var( "SELECT id FROM {$wpdb->prefix}icl_string_translations WHERE string_id={$string_id} AND language='{$lang}'" ) ) {
								icl_add_string_translation( $string_id, $lang, $translation, ICL_TM_COMPLETE );
							}
						}
					}
				}
			}

		}
		echo '1|' . $scan_stats;
		exit;
	}

	// Localization

	function icl_dashboard_widget_content()
	{
		global $wpdb;
		?>

		<div><a href="javascript:void(0)" onclick="jQuery(this).parent().next('.wrapper').slideToggle();"
				style="display:block; padding:5px; border: 1px solid #eee; margin-bottom:2px; background-color: #F7F7F7;"><?php _e( 'String translation', 'wpml-string-translation' ) ?></a></div>
		<div class="wrapper" style="display:none; padding: 5px 10px; border: 1px solid #eee; border-top: 0; margin:-11px 0 2px 0;">
			<p><?php echo __( 'String translation allows you to enter translation for texts such as the site\'s title, tagline, widgets and other text not contained in posts and pages.', 'wpml-string-translation' ) ?></p>
			<?php
			$strings_need_update = $wpdb->get_var( "SELECT COUNT(id) FROM {$wpdb->prefix}icl_strings WHERE status <> 1" );
			?>
			<?php if ( $strings_need_update == 1 ): ?>
				<p>
					<b><?php printf( __( 'There is <a href="%s"><b>1</b> string</a> that needs to be updated or translated. ', 'wpml-string-translation' ), 'admin.php?page=' . WPML_ST_FOLDER . '/menu/string-translation.php&amp;status=0' ) ?></b>
				</p>
			<?php elseif ( $strings_need_update ): ?>
				<p>
					<b><?php printf( __( 'There are <a href="%s"><b>%s</b> strings</a> that need to be updated or translated. ', 'wpml-string-translation' ), 'admin.php?page=' . WPML_ST_FOLDER . '/menu/string-translation.php&amp;status=0', $strings_need_update ) ?></b>
				</p>
			<?php else: ?>
				<p><?php echo __( 'All strings are up to date.', 'wpml-string-translation' ); ?></p>
			<?php endif; ?>

			<p>
				<a class="button secondary" href="<?php echo 'admin.php?page=' . WPML_ST_FOLDER . '/menu/string-translation.php' ?>"><?php echo __( 'Translate strings', 'wpml-string-translation' ) ?></a>
			</p>
		</div>
	<?php
	}

	function plugin_po_file_download( $file = false, $recursion = 0 )
	{
		global $__wpml_st_po_file_content;

		if ( empty( $file ) && !empty( $_GET[ 'file' ] ) ) {
			$file = WP_PLUGIN_DIR . '/' . $_GET[ 'file' ];
		}
		if ( empty( $file ) )
			return;

		if ( is_null( $__wpml_st_po_file_content ) ) {
			$__wpml_st_po_file_content = '';
		}

		require_once ICL_PLUGIN_PATH . '/inc/potx.php';

		if ( is_file( $file ) && WP_PLUGIN_DIR == dirname( $file ) ) {

			_potx_process_file( $file, 0, '__pos_scan_store_results', '_potx_save_version', POTX_API_7 );
		} else {

			if ( !$recursion ) {
				$file = dirname( $file );
			}

			if ( is_dir( $file ) ) {
				$dh = opendir( $file );
				while ( $dh && false !== ( $f = readdir( $dh ) ) ) {
					if ( 0 === strpos( $f, '.' ) )
						continue;
					$this->plugin_po_file_download( $file . '/' . $f, $recursion + 1 );
				}
			} elseif ( preg_match( '#(\.php|\.inc)$#i', $file ) ) {
				_potx_process_file( $file, 0, '__pos_scan_store_results', '_potx_save_version', POTX_API_7 );
			}
		}

		if ( ! $recursion ) {
			$po = "";
			$po .= '# This file was generated by WPML' . PHP_EOL;
			$po .= '# WPML is a WordPress plugin that can turn any WordPress site into a full featured multilingual content management system.' . PHP_EOL;
			$po .= '# https://wpml.org' . PHP_EOL;
			$po .= 'msgid ""' . PHP_EOL;
			$po .= 'msgstr ""' . PHP_EOL;
			$po .= '"Content-Type: text/plain; charset=utf-8\n"' . PHP_EOL;
			$po .= '"Content-Transfer-Encoding: 8bit\n"' . PHP_EOL;
			$po_title = 'WPML_EXPORT';
			if ( isset( $_GET[ 'context' ] ) ) {
				$po_title .= '_' . $_GET[ 'context' ];
			}
			$po .= '"Project-Id-Version:' . $po_title . '\n"' . PHP_EOL;
			$po .= '"POT-Creation-Date: \n"' . PHP_EOL;
			$po .= '"PO-Revision-Date: \n"' . PHP_EOL;
			$po .= '"Last-Translator: \n"' . PHP_EOL;
			$po .= '"Language-Team: \n"' . PHP_EOL;
			$translation_language = 'en';
			if ( isset( $_GET[ 'translation_language' ] ) ) {
				$translation_language = $_GET[ 'translation_language' ];
			}
			$po .= '"Language:' . $translation_language . '\n"' . PHP_EOL;
			$po .= '"MIME-Version: 1.0\n"' . PHP_EOL;

			$po .= $__wpml_st_po_file_content;

			header( "Content-Type: application/force-download" );
			header( "Content-Type: application/octet-stream" );
			header( "Content-Type: application/download" );
			header( 'Content-Transfer-Encoding: binary' );
			header( "Content-Disposition: attachment; filename=\"" . basename( $file ) . ".po\"" );
			header( "Content-Length: " . strlen( $po ) );
			echo $po;
			exit( 0 );
		}

	}

	function estimate_word_count( $string, $lang_code )
	{
		$__asian_languages = array( 'ja', 'ko', 'zh-hans', 'zh-hant', 'mn', 'ne', 'hi', 'pa', 'ta', 'th' );
		$words             = 0;
		if ( in_array( $lang_code, $__asian_languages ) ) {
			$words += strlen( strip_tags( $string ) ) / 6;
		} else {
			$words += count( explode( ' ', strip_tags( $string ) ) );
		}

		return (int)$words;
	}

	function icl_st_cancel_local_translation() {
		$id        = filter_input( INPUT_POST, 'id', FILTER_VALIDATE_INT );
		$string_id = $this->cancel_local_translation( $id, true );
		echo wp_json_encode( array( 'string_id' => $string_id ) );
		exit;
	}

	function cancel_remote_translation( $rid ) {
		/** @var wpdb $wpdb */
		global $wpdb;

		$translation_ids = $wpdb->get_col( $wpdb->prepare( "	SELECT string_translation_id
															FROM {$wpdb->prefix}icl_string_status
															WHERE rid = %d",
		                                                   $rid ) );
		$cancel_count    = 0;
		foreach ( $translation_ids as $translation_id ) {
			$res          = (bool) $this->cancel_local_translation( $translation_id );
			$cancel_count = $res ? $cancel_count + 1 : $cancel_count;
		}

		return $cancel_count;
	}

	function cancel_local_translation( $id, $return_original_id = false ) {
		global $wpdb;
		$string_id = $wpdb->get_var( $wpdb->prepare( "	SELECT string_id
														FROM {$wpdb->prefix}icl_string_translations
														WHERE id=%d AND status IN (%d, %d)",
		                                             $id,
		                                             ICL_TM_IN_PROGRESS,
		                                             ICL_TM_WAITING_FOR_TRANSLATOR ) );
		if ( $string_id ) {
			$wpdb->update( $wpdb->prefix . 'icl_string_translations',
			               array(
				               'status'              => ICL_TM_NOT_TRANSLATED,
				               'translation_service' => null,
				               'translator_id'       => null,
				               'batch_id'            => null
			               ),
			               array( 'id' => $id ) );
			icl_update_string_status( $string_id );
			$res = $return_original_id ? $string_id : $id;
		} else {
			$res = false;
		}

		return $res;
	}

	function icl_st_string_status()
	{
		global $wpdb, $icl_st_string_translation_statuses;
		$string_id = $_POST[ 'string_id' ];
		echo $icl_st_string_translation_statuses[ ( $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$wpdb->prefix}icl_strings WHERE id=%d", $string_id ) ) ) ];
		exit;
	}
	
	function pre_update_option_blogname($value, $old_value) {
		return $this->pre_update_option_settings("Blog Title", $value, $old_value);
	}
	
	function pre_update_option_blogdescription($value, $old_value) {
		return $this->pre_update_option_settings("Tagline", $value, $old_value);
	}
	
	function pre_update_option_settings($option, $value, $old_value) {
		global $sitepress, $sitepress_settings;
		
		$current_language = $sitepress->get_current_language();
		$strings_language = $sitepress_settings['st']['strings_language'];
		if ($current_language == $strings_language) {
			return $value;
		}
		
		WPML_Config::load_config_run();
		$result = icl_update_string_translation($option, $current_language, $value, ICL_TM_COMPLETE);
		if ($result) {
			// returning old_value in place of value will stop update_option() processing. 
			// do not remove it!
			return $old_value;
		}
		
		return $value;
		
	}

	public function get_string_filter( $lang ) {

		if ( ! $this->strings_autoregister ) {
			$this->string_filters[ $lang ] = isset( $this->string_filters[ $lang ] ) ? $this->string_filters[ $lang ] : new WPML_Displayed_String_Filter( $lang );
		} else {
			$this->string_filters[ $lang ] = $this->get_admin_string_filter( $lang );
		}

		return $this->string_filters[ $lang ];
	}

	public function get_admin_string_filter( $lang ) {
		if ( ! ( isset( $this->string_filters[ $lang ] )
		         && get_class( $this->string_filters[ $lang ] ) == 'WPML_Admin_String_Filter' )
		) {
			$this->string_filters[ $lang ] = isset( $this->string_filters[ $lang ] ) ? $this->string_filters[ $lang ] : false;
			$this->string_filters[ $lang ] = new WPML_Admin_String_Filter( $lang, $this->string_filters[ $lang ] );
		}

		return $this->string_filters[ $lang ];
	}

	public function set_auto_register_status() {
		$string_settings = apply_filters('WPML_get_setting', false, 'st' );
		$icl_st_auto_reg = isset($string_settings[ 'icl_st_auto_reg' ]) ? $string_settings[ 'icl_st_auto_reg' ] : false;
		$auto_reg        = filter_var( $icl_st_auto_reg, FILTER_SANITIZE_STRING );

		$this->strings_autoregister = $auto_reg == 'auto-always' || ( $auto_reg == 'auto-admin' && current_user_can( 'manage_options' ) );

		return $this->strings_autoregister;
	}

	public function get_strings_language( $language = '' ) {
		$string_settings = $this->get_strings_settings();

		$string_language = $language ? $language : 'en';
		if ( isset( $string_settings[ 'strings_language' ] ) ) {
			$string_language = $string_settings[ 'strings_language' ];
		}

		return $string_language;
	}

	//TODO: [WPML 3.3] This will be needed in future and for forward compatibility, is currently needed in Package Translation
	public function get_default_context_language( $language, $context_name ) {
		$context_language = $this->get_strings_language( $language );
		if ( $context_name ) {
			$context_language = 'en';
		}

		return $context_language;
	}

	public function delete_all_string_data($string_id) {
		global $wpdb;

		$icl_string_positions_query    = "DELETE FROM {$wpdb->prefix}icl_string_positions WHERE string_id=%d";
		$icl_string_status_query       = "DELETE FROM {$wpdb->prefix}icl_string_status WHERE string_translation_id IN (SELECT id FROM {$wpdb->prefix}icl_string_translations WHERE string_id=%d)";
		$icl_string_translations_query = "DELETE FROM {$wpdb->prefix}icl_string_translations WHERE string_id=%d";
		$icl_strings_query             = "DELETE FROM {$wpdb->prefix}icl_strings WHERE id=%d";

		$icl_string_positions_prepare    = $wpdb->prepare( $icl_string_positions_query, $string_id );
		$icl_string_status_prepare       = $wpdb->prepare( $icl_string_status_query, $string_id );
		$icl_string_translations_prepare = $wpdb->prepare( $icl_string_translations_query, $string_id );
		$icl_strings_prepare             = $wpdb->prepare( $icl_strings_query, $string_id );

		$wpdb->query( $icl_string_positions_prepare );
		$wpdb->query( $icl_string_status_prepare );
		$wpdb->query( $icl_string_translations_prepare );
		$wpdb->query( $icl_strings_prepare );

	}

	public function get_strings_settings() {
		global $sitepress;

		$string_settings                       = $sitepress ? $sitepress->get_string_translation_settings() : array();
		$string_settings[ 'strings_language' ] = 'en';
		if ( ! isset( $string_settings[ 'icl_st_auto_reg' ] ) ) {
			$string_settings[ 'icl_st_auto_reg' ] = 'disable';
		}
		$string_settings[ 'strings_per_page' ] = ICL_STRING_TRANSLATION_AUTO_REGISTER_THRESHOLD;

		return $string_settings;
	}

	function send_strings_to_translation_service( $string_ids, $target_language, $basket_name, $translator_id ) {
		global $wpdb;
		// get all the untranslated strings
		$untranslated = array();
		foreach ( $string_ids as $st_id ) {
			$untranslated[ ] = $st_id;
		}

		if ( sizeof( $untranslated ) > 0 ) {
			$project = TranslationProxy::get_current_project();

			$strings    = array();
			$word_count = 0;

			$source_language = $this->get_strings_language();
			foreach ( $untranslated as $string_id ) {
				$string_data_query   = "SELECT id, context, name, value FROM {$wpdb->prefix}icl_strings WHERE id=%d";
				$string_data_prepare = $wpdb->prepare( $string_data_query, $string_id );
				$string_data         = $wpdb->get_row( $string_data_prepare );
				$word_count += $this->estimate_word_count( $string_data->value, $source_language );
				$strings[ ] = $string_data;
			}

			$xliff = new WPML_TM_xliff();
			$file = $xliff->get_strings_xliff_file( $strings, $source_language, $target_language );

			$title     = "String Translations";
			$cms_id    = '';
			$url       = '';
			$timestamp = date( 'Y-m-d H:i:s' );

			if ( TranslationProxy::is_batch_mode() ) {
				$res = $project->send_to_translation_batch_mode( $file,
				                                                 $title,
				                                                 $cms_id,
				                                                 $url,
				                                                 $source_language,
				                                                 $target_language,
				                                                 $word_count );
			} else {
				$res = $project->send_to_translation( $file,
				                                      $title,
				                                      $cms_id,
				                                      $url,
				                                      $source_language,
				                                      $target_language,
				                                      $word_count );
			}

			if ( $res ) {
				foreach ( $strings as $string_data ) {


					$batch_id            = TranslationManagement::update_translation_batch( $basket_name );
					$translation_service = TranslationProxy_Service::get_translator_data_from_wpml( $translator_id );
					$added               = icl_add_string_translation( $string_data->id,
					                                                   $target_language,
					                                                   null,
					                                                   ICL_TM_WAITING_FOR_TRANSLATOR,
					                                                   $translation_service[ 'translator_id' ],
					                                                   $translation_service[ 'translation_service' ],
					                                                   $batch_id );
					if ( $added ) {
						$data = array(
							'rid'                   => $res,
							'string_translation_id' => $added,
							'timestamp'             => $timestamp,
							'md5'                   => md5( $string_data->value ),
						);
						$wpdb->insert( $wpdb->prefix . 'icl_string_status', $data ); //insert rid
					} else {
						$this->add_message( sprintf( __( 'Unable to add "%s" string in tables', 'sitepress' ),
						                             $string_data->name ),
						                    'error' );

						return 0;
					}
				}
				$wpdb->insert( $wpdb->prefix . 'icl_core_status',
				               array(
					               'rid'    => $res,
					               'module' => '',
					               'origin' => $source_language,
					               'target' => $target_language,
					               'status' => CMS_REQUEST_WAITING_FOR_PROJECT_CREATION
				               ) );

				if ( $project->errors && count( $project->errors ) ) {
					$res[ 'errors' ] = $project->errors;
				}

				return $res;
			}
		}

		return 0;
	}

	function get_string_job_id( $args ) {
		global $wpdb;

		$where_string = false;
		if ( $args ) {
			foreach ( $args as $key => $value ) {
				if ( $where_string ) {
					$where_string .= ' AND ';
				}
				$where_string .= $key . ' = %d';
			}
		}

		if ( $where_string ) {
			$where_values = array_values( $args );
			$job_id       = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}icl_string_status WHERE " . $where_string, $where_values ) );

			if ( $job_id !== null ) {
				return $job_id;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}

function __pos_scan_store_results( $string, $domain, $file, $line )
{
	global $__wpml_st_po_file_content;
	static $strings = array();

	//avoid duplicates
	if ( isset( $strings[ $domain ][ $string ] ) ) {
		return false;
	}
	$strings[ $domain ][ $string ] = true;

	$file = @file( $file );
	if ( !empty( $file ) ) {
		$__wpml_st_po_file_content .= PHP_EOL;
		$__wpml_st_po_file_content .= '# ' . @trim( $file[ $line - 2 ] ) . PHP_EOL;
		$__wpml_st_po_file_content .= '# ' . @trim( $file[ $line - 1 ] ) . PHP_EOL;
		$__wpml_st_po_file_content .= '# ' . @trim( $file[ $line ] ) . PHP_EOL;
	}

	//$__wpml_st_po_file_content .= 'msgid "'.str_replace('"', '\"', $string).'"' . PHP_EOL;
	$__wpml_st_po_file_content .= PHP_EOL;
	$__wpml_st_po_file_content .= 'msgid "' . $string . '"' . PHP_EOL;
	$__wpml_st_po_file_content .= 'msgstr ""' . PHP_EOL;

}
