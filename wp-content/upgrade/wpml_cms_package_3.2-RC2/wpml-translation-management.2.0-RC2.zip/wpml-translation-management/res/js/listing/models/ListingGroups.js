Translation_Jobs.listing.models.ListingGroups = Backbone.Collection.extend({
	model: Translation_Jobs.listing.models.ListingGroup
	,initialize: function(){
	},
	parse:function(data)
	{
		return data;
	}
});
