<?php 
/*
Plugin Name: WPML XLIFF
Plugin URI: https://wpml.org/
Description: Import and Export XLIFF files for translation
Author: OnTheGoSystems
Author URI: http://www.onthegosystems.com/
Version: 0.9.9-RC2
Deprecated: 0.9.8
*/

if (defined('WPML_XLIFF_VERSION')) return;

define('WPML_XLIFF_VERSION', '0.9.9');
define('WPML_XLIFF_PATH', dirname(__FILE__));
define('WPML_XLIFF_OLD_FOLDER', basename(WPML_XLIFF_PATH));


register_activation_hook( WP_PLUGIN_DIR . '/' . WPML_XLIFF_OLD_FOLDER . '/plugin.php', 'wpml_xliff_plugin_activate'  );
register_deactivation_hook( WP_PLUGIN_DIR . '/' . WPML_XLIFF_OLD_FOLDER . '/plugin.php', 'wpml_xliff_plugin_deactivate' );

function wpml_xliff_plugin_activate() {

	wpml_xliff_warning();

}

function wpml_xliff_plugin_deactivate() {

	if (class_exists("ICL_AdminNotifier") && method_exists( "ICL_AdminNotifier", "remove_message" ) && ICL_AdminNotifier::message_id_exists( "wpml_xliff_deprecated" )) {
		ICL_AdminNotifier::remove_message( "wpml_xliff_deprecated" );
	}

}

function wpml_xliff_warning() {

	if (class_exists("ICL_AdminNotifier") && method_exists( "ICL_AdminNotifier", "add_message" )) {
		$message          = __( 'XLIFF is now included with WPML\'s Translation Management. Please uninstall the XLIFF plugin', 'wpml-xliff' );

		$args = array(
			'id'           => 'wpml_xliff_deprecated',
			'group'        => 'translation_management_plugins_checks',
			'msg'          => $message,
			'type'         => 'error',
			'admin_notice' => true,
			'hide'         => false
		);
		ICL_AdminNotifier::add_message( $args );
	}
}
