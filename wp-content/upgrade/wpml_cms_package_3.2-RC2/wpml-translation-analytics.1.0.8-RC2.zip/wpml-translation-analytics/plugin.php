<?php 
/*
Plugin Name: WPML Translation Analytics
Plugin URI: https://wpml.org/
Description: <b>This plugin is deprecated</b>. Shows the status of translation projects and displays warnings when completion time may not be met. <a href="https://wpml.org">Documentation</a>.
Author: OnTheGoSystems
Author URI: http://www.onthegosystems.com/
Version: 1.0.8-RC2
Deprecated: 1.0.7
*/
define( 'WPML_TRANSLATION_ANALYTICS_VERSION', '1.0.7' );
define( 'WPML_TRANSLATION_ANALYTICS_PATH', dirname( __FILE__ ) );
define( 'WPML_TRANSLATION_ANALYTICS_FOLDER', basename(WPML_TRANSLATION_ANALYTICS_PATH));

register_deactivation_hook( WP_PLUGIN_DIR . '/' . WPML_TRANSLATION_ANALYTICS_FOLDER . '/plugin.php', 'wpml_translation_analytics_plugin_deactivate' );


add_action('admin_notices',	'wpml_translation_analytics_warning');


function wpml_translation_analytics_plugin_deactivate() {

	if (class_exists("ICL_AdminNotifier") && method_exists( "ICL_AdminNotifier", "remove_message" ) && ICL_AdminNotifier::message_id_exists( "translation_analytics_deprecated" )) {
		ICL_AdminNotifier::remove_message( "translation_analytics_deprecated" );
	}

}

function wpml_translation_analytics_warning() {

	?>
	<div class="message error">
		<p>
		<?php
			_e( "Translation Analytics is now included with WPML's Translation Management. Please uninstall the Translation Analytics plugin.", 'wpml-translation-analytics' );
		?>
		</p>
	</div>

	<?php		
}
